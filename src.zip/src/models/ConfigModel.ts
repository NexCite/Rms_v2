interface ConfigModel {
  name: string;
  version: string;
  logo: string;
}
