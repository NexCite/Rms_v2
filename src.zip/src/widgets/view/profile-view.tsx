"use client";
import React from "react";

export default function ProfileView() {
  return <div>ProfileView</div>;
}
