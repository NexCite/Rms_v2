type UplaodType = "s3" | "local";
export default UplaodType;
