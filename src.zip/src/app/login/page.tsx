import LoginWidget from "@rms/widgets/login/login-widget";
import React from "react";

export default function Login() {
  return (
    <div>
      <LoginWidget />
    </div>
  );
}
