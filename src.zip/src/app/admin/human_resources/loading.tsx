import Loading from "@rms/components/ui/loading";

export default function loading() {
  return <Loading />;
}
