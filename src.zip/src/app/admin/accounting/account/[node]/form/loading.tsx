import Loading from "@rms/components/ui/loading";
import React from "react";

export default function loading() {
  return <Loading />;
}
