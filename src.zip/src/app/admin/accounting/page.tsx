import React from "react";

export default function Accounting() {
  return <div></div>;
}
