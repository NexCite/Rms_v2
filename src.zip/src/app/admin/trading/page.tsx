import React from "react";

export default function page() {
  return (
    <div style={{ display: "flex", justifyContent: "center" }}>
      <h1>Welcome To Trading System</h1>
    </div>
  );
}
